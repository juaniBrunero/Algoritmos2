package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Animal animal = new Carnivoro();
        animal.mirar();

        // Ejemplo de método de clase ó estático.
        Digeridor.comenzar(animal);


        // Ejemplo parametro por consola
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escribe algo: ");
        String mensaje = scanner.nextLine();
        System.out.println(mensaje);

        animal.digerir();
        animal.digerir(new Alimento());
    }
}
