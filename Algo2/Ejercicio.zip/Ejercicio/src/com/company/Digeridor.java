package com.company;

/**
 * Created by arielpineiro on 5/26/17.
 */
public class Digeridor {

    static void comenzar(Animal animal) {
        animal.digerir();
    }

}
