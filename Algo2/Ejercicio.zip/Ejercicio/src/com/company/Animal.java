package com.company;

/**
 * Created by arielpineiro on 5/26/17.
 */
public abstract class Animal {

    abstract void digerir();
    abstract void digerir(Alimento alimento);

    public void mirar() {
        System.out.print("Estoy mirando...");
    }
}
