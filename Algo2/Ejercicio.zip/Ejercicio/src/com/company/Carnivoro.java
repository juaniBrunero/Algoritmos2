package com.company;

/**
 * Created by arielpineiro on 5/26/17.
 */
public class Carnivoro extends Animal {

    @Override
    void digerir() {
        System.out.println("Digiriendo como carnivo");
    }

    @Override
    void digerir(Alimento alimento) {
        System.out.println("Digiriendo como carnivo");
    }
}
