package com.company;

public class Main {

    public static void main(String[] args) {
	    Persona juan = new Alumno("Juan", 223344556, new Certificado());
        System.out.println("Nombre: " + juan.getNombre());
        System.out.println("DNI: " + juan.getDni());

    }
}

class Persona {
    private String nombre;
    private Integer dni;

    Persona() {

    }

    Persona (String nombre, Integer dni) {
        this.nombre = nombre;
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return this.nombre;
    }

    public Integer getDni() {
        return this.dni;
    }
}


class Certificado {

}

class Alumno extends Persona {

    private Certificado certificado;

    Alumno(String nombre, Integer dni) {
        super(nombre, dni);
    }

    Alumno(String nombre, Integer dni, Certificado certificado) {
        super(nombre, dni);
        this.certificado = certificado;
    }

    public Certificado getCertificado() {
        return this.certificado;
    }
}

class Profesor extends Persona {

}